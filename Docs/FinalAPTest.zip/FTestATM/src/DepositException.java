
public class DepositException extends Exception {

}
