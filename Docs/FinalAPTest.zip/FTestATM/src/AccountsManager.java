import java.util.*;
import java.io.*;

interface Manageable
{
   public Account getAccount(String ID, String pw) throws InvalidID;
   public double withdraw(String accId, String pw, double amt) throws 
                                                  WithdrawException, InvalidID;
   public double deposit(String accId, String pw, double amt) throws   
                           DepositException, 
                                                                    InvalidID;
   public void save() throws IOException;
}

class AccountsManager // implements  Manageable , ....
{






}

