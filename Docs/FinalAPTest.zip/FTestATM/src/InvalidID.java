
public class InvalidID extends Exception {

}
